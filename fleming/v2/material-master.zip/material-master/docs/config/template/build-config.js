DocsApp.constant('BUILDCONFIG', {$ doc.buildConfig | json $});
