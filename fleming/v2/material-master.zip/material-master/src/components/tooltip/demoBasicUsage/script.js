angular.module('tooltipDemo1', ['ngMaterial'])

.controller('AppCtrl', function($scope) {
});
