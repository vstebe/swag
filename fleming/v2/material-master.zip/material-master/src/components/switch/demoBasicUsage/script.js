angular.module('switchDemo1', ['ngMaterial']);
